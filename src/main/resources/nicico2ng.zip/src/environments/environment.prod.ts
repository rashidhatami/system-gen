export const environment = {
  production: true,
  baseServiceUrl: 'http://localhost:8181/ngo',
  securityServiceUrl: 'http://localhost:8282/ngo-sso'
};
